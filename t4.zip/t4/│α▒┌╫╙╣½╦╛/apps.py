from django.apps import AppConfig


class 赤壁子公司Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = '赤壁子公司'
