from django.apps import AppConfig


class 用电量Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = '用电量'
