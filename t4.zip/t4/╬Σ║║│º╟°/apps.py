from django.apps import AppConfig


class 武汉厂区Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = '武汉厂区'
