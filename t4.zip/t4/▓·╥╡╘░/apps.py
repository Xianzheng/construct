from django.apps import AppConfig


class 产业园Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = '产业园'
