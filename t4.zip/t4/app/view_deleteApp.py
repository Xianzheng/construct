# -*- coding:utf-8 _*-

from django.shortcuts import render, redirect
from django.http.response import HttpResponse
from django.contrib.auth.decorators import login_required
from .models import *
from .tools_visual import *
from .tools2 import *
from pathlib import Path
import os,json
import urllib
from .view_plugin_tools import *
BASE_DIR = Path(__file__).resolve().parent
appName = str(BASE_DIR).split('\\')[-1]



def deleteApp_view(request):

    rootPath = os.getcwd()
    
    appName = request.get_full_path().split('=')[1]
    
    appName = appName.split('/')[0]

    name = urllib.parse.unquote(appName)

    import importlib
    # table1 = importlib.import_module('.models', package=appName)
    module=importlib.import_module(name+".models")
    toDelete =getattr(module,'table1')


    #得到table Instance
    modelsList = getModelList('./{}/models.py'.format(name))
    #class 包含temp 的不会被删除
    modelsList = [i for i in modelsList if 'temp' not in i]
    #得到modelsList的所有表名，得到Instance 并删除
    # print(modelsList)
    
   
    
    for tableName in modelsList[::-1]:
        print(tableName)
        tableInstance = getattr(module,tableName)
        tableInstance.objects.all().delete()

  
    '''
        remove path from main Path
    '''
    removePath(appName)

    '''
        unInstallApp from setting
    '''
    unistallApp(appName)
    '''
        delete all files
    '''
    print('delete All Files')
    appName = urllib.parse.unquote(appName)

    folderPath = rootPath +'\\'+appName

    # print(folderPath)

    deleteFolderContent(folderPath)

    lst = [i for i in os.listdir(rootPath) if '.' not in i]

    #delete empty folder
    for item in lst:
        if not os.listdir(item):
            os.rmdir(item)
    # os.rmdir(rootPath)
    # print('os list is',os.listdir(rootPath))
    

   
    return HttpResponse(json.dumps({'fileList':'删除成功'}))

def getAppName_view(request):

    oldPath = os.getcwd()

    rootName = oldPath.split('\\')[-1]
    print(rootName)
    appNameList = os.listdir(oldPath)

    appNameList = [i for i in appNameList 
                    if '.' not in i and i not in [appName,rootName,'mystatic','account']]
    
    return HttpResponse(json.dumps({'fileList':appNameList}))