
from django.shortcuts import render, redirect
from django.http.response import HttpResponse
from django.contrib.auth.decorators import login_required
from .tools import *
from .models import *
from .forms import *


exclude = ['username','email','is_staff','last_login','password','last_name','date_joined','is_active','is_superuser']
appName = getAppName()

        
@login_required(login_url="/acount/login/")
def table1_view(request):
    print(getmodelfield(appName,'table1',exclude))
    dic = getmodelfield(appName,'table1',exclude)
    lst = list(dic.keys())
    print(lst)
    # get current app Name
    

    tableObj = getThirdAppLib1(appName)
    
    modelName = 'table1'
    
    nextModleName = ''

    objLst = tableObj.objects.all()
    
    try:
        #obj是一个表中的第一行数据
        obj = objLst[0]
        #传入obj的字典格式obj.__dict__函数getheader得到表的第二项到最后一项
        #cs 得到所有 该app下 models里 名为modelName class的所有字段的 verbose name 
        cs = getmodelfield(appName, modelName,exclude)
        #根据表字段整理出表header，接下来要处理表没有数据问题
        header = getHeader(obj.__dict__,start = 1, end = len(obj.__dict__) -1,cs = cs)
        header1 = getHeader(obj.__dict__,start = 2, end = (len(obj.__dict__)),cs = None)
        header1.pop()
        header.pop()
        # print(header)
        #render style
        width = [50,50,70,70]
        #width里是表字段内容显示长度，修改，删除，分析的长度在renderTable.html里
        renderFile = './table/renderTable1.html' 
        #render header内容
        headerAndWidth = zip(header,width)
        #得到表的value
        department = getUrlParameter(request,token="department=")
        #解析url得到token值
        url = getFullUrl(request)
        #得到带parameters的url
        if 'department=' in url:
            objLst = tableObj.objects.filter(使用部门=department).order_by('年份','月份')
        else:
            objLst = tableObj.objects.all().order_by('id')
        #遍历所有表的所有信息填入进空的lst中
        objLst = objLst[::-1]
        totalData = loadData(objLst, header1)
        # print('line28',totalData)
        page_obj = getPaginationObject(request,totalData)

        #返回渲染template
        return render(request,renderFile,{'modelName':modelName,
                    'headerAndWidth':headerAndWidth,
                    'totalData':totalData,'status':0,'tableId':0,
                    'goback':'/logout/','nextLayout':'/'+appName+'/'+nextModleName,
                    'appName':appName,'page_obj':page_obj})
    except:
        cs = getmodelfield(appName, modelName)
        #根据表字段整理出表header，接下来要处理表没有数据问题
        header = getHeader(obj.__dict__,start = 1, end = len(obj.__dict__) -1,cs = cs)
        header1 = getHeader(obj.__dict__,start = 2, end = (len(obj.__dict__)),cs = None)
        header1.pop()
        header.pop()
        # print(header)
        #render style
        width = [50,50,70,70]
        #width里是表字段内容显示长度，修改，删除，分析的长度在renderTable.html里
        renderFile = './table/renderTable1.html' 
        #render header内容
        headerAndWidth = zip(header,width)
        renderFile = './table/renderTable1.html'  
        return render(request,renderFile,{'modelName':modelName,
                    'headerAndWidth':headerAndWidth,
                    'totalData':'','status':0,'tableId':0,
                    'goback':'/logout/','nextLayout':'/'+appName+'/'+nextModleName,'appName':appName})

@login_required(login_url="/login/")
def addSubTable_view(request,tableId,tableModel):
    
    path = request.path
    modelName = path.split('/')[-1]
    formName = modelName +'_Form'
    # print(formName)
    # print(globals().keys())
    form = globals()[formName]
    model = globals()[modelName]
    modelnameLst = ['table1']
    prevmodelname = ''
    for index in range(len(modelnameLst)):
        if modelnameLst[index] == modelName: 
            if index != 0:
                prevmodelname = modelnameLst[index - 1]
    
    # print(tableId)
    if request.method == 'POST':
        form = form(request.POST)
        if form.is_valid():
            instance = form.save(commit=False)
            if tableId == '0':# 如果tableId等于0意味着根表，没有foreign key
                pass
            else:
                # instance.bind = model.objects.get(id = tableId)
                bindTable = prevmodelname
                bindModel = globals()[bindTable]
                instance.bind = bindModel.objects.get(id = tableId)

            url =  request.get_full_path()
            url = urllib.parse.unquote(url)
            department = ''
        
            if 'department=' in url:
                department = url.split('department=')[-1]
                
                instance.使用部门 = department
                
            instance.save()
            
            rd = tableModel[0].lower() + tableModel[1:]

            if tableId == '0':
                if 'department=' in url:
                    return redirect('/用电量/'+rd+'/?department='+department)
                else:
                    return redirect('/用电量/'+rd)
            
                
            return redirect('/用电量/'+rd+'/'+tableId)
    else:

        path = request.path
        modelName = path.split('/')[-1]
        formName = modelName +'_Form'
        form = globals()[formName]
        title = '添加厂区'
        rd = tableModel[0].lower() + tableModel[1:]
        goback = ''
        print(tableId)
        if tableId == '0':
            goback = '/用电量/'+rd
            # print('yes')
        else:
            goback = '/用电量/'+rd+'/'+tableId
            # print('no')
        # print(goback)
        
        print('tableModel is',tableModel)
       

    return render(request,'form.html',{'form':form,
    'tableName':title,'goback':goback,'appName':'用电量'})
                
def updateRow_view(request,modelName,rowId,tableId):
    tableObj = getThirdAppLib1(appName)
    obj = tableObj.objects.get(id = rowId)
    formName = modelName +'_Form'
    form = globals()[formName]
    modelnameLst = ['table1']
    department = getUrlParameter(request,'department=')
    if request.method == 'POST':
        form = form(request.POST,instance = obj)
        if form.is_valid():
            form.save()
            if modelName == modelnameLst[0]:
                 return redirect("/"+appName+"/"+modelName+"/"+'?department='+department)
            return redirect("/"+appName+"/"+modelName+"/"+tableId+'/'+'?department='+department)

    form = form(instance = obj)
    title = ''
    action = '/'+appName+'/updateRow/'+modelName+'/'+rowId+'/'+tableId
    goback = '/'+appName+'/'+modelName+'/'+tableId
    return render(request,'form.html',
    {'form':form,'tableName':title,
    'tableId':tableId,'action':action,'goback':goback,'appName':appName})



def deleteRow_view(request,modelName,rowId,tableId):
    modelInstance = globals()[modelName]
    
    modelnameLst = ['table1', 'table2', 'table3']

    obj = modelInstance.objects.get(id = rowId)

    obj.delete()
    #先删除在查找

    department = getUrlParameter(request,'department=')

    
    if modelName == modelnameLst[0]:
        goback = '/'+appName+'/'+modelName+'/?department='+department
    else:
        
        goback = '/'+appName+'/'+modelName+'/' + tableId +'/?department='+department

    # print(goback)
       
    return redirect(goback)


