from .models import *
from django import forms
from .tools import *
appName = getAppName()

choiceYear = (
        ('2021','2021'),
        ('2022', '2022'),
        ('2023', '2023'),
        ('2024', '2024'),
        ('2025', '2025'),
        ('2026', '2026'),
        ('2027', '2027'),
        ('2028', '2028'),
        ('2029', '2029W'),
    )

choiceMonth = (
        (1, 1),
        (2, 2),
        (3, 3),
        (4, 4),
        (5, 5),
        (6, 6),
        (7, 7),
        (8, 8),
        (9, 9),
        (10, 10),
        (11, 11),
        (12, 12),
    )

class table1_Form(forms.ModelForm):
    class Meta:
        model = table1

        fields = "__all__"

        exclude = ['id','bind','使用部门']

        dic = getmodelfield(appName,'table1',exclude)
        lst = list(dic.keys())
        print(lst)
        print(lst[3])
        
        widgets = {
                    lst[1]:  forms.Select(choices=choiceYear),
                    lst[2]:  forms.Select(choices=choiceMonth),
                    lst[3]:  forms.NumberInput(),
                    '金额元':  forms.NumberInput(),
                }

            