from django.urls import path ,include
from .views import *
from .view_dataAnalyze import *
from .view_export import *

urlpatterns = (
    path('table1/',table1_view),
    path('updateRow/<modelName>/<rowId>/<tableId>',updateRow_view),
    path('deleteRow/<modelName>/<rowId>/<tableId>',deleteRow_view),
    path('monthDataAnalyze/<data>/',monthDataAnalyze_view),
    path('constantDataAnalyze/',constantDataAnalyze_view),
    path('export/',export_view),
    path('constantDataAnalyze/',constantDataAnalyze_view),
    path('getYearOption/',getYearOption_view),
    path('addSubTable/<tableId>/<tableModel>',addSubTable_view),
)
