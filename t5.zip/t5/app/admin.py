from django.contrib import admin
from .models import *
admin.site.register(table1)
admin.site.register(table2)
admin.site.register(table3)
