
# -*- coding:utf-8 _*-
import re
from django.shortcuts import render, redirect
from django.http.response import HttpResponse
from django.contrib.auth.decorators import login_required
from .models import *
from .tools_visual import *
from .tools2 import *
from .tools import *
from pathlib import Path
import os,json,shutil,time
import urllib
from .view_plugin_tools import *
from django.core.management import call_command

BASE_DIR = Path(__file__).resolve().parent
appName = str(BASE_DIR).split('\\')[-1]
import pandas as pd

def loadExcelToTable_view(request):
    oldPath = os.getcwd()
    
    os.chdir(os.getcwd()+'\\mystatic\\uploadFiles')
    appName = request.POST.get('appName')
    fileName = request.POST.get('fileName')
    print(appName)
    print(fileName)
    
    df = pd.read_excel(fileName)
    for i in df:
        print(i)
    lib = getThirdAppLib(request,appName)
    
    dic = {'年份':'2022','月份':1,'水使用量吨':1234,'金额元':1234.00,'使用部门':'产业园'}
    # print(len(df.axes[0]))
    num = len(df.axes[0])
    for i in range(num):
        tempDic = df.loc[i].to_dict()
        tempDic['年份'] = str(tempDic['年份'])
        lib.objects.create(**tempDic)
     # lib.objects.create(**dic)        
    os.chdir(oldPath)
    return  HttpResponse(json.dumps({'fileList':'connect'}))

