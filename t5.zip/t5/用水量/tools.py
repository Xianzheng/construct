import datetime
from django.apps import apps
from .models import * 
import urllib

def loadData(objLst,header:list) -> list:
    #遍历所有表的所有信息填入total list中
    #最后total会变成比如[[],[],[]]

    total = []
    # print('header is',header)
    count = 0
    for obj in objLst:
        # temp装的的是每行的内容
        dic = {}
        temp = []
        # idlst 给每行的内容绑上相同的id
        count += 1
        id = obj.id
        for i in header:
            # getattr(obj,i)可以得到class instance 里 属性i的值
            # 這裏傳入的是modle的原生attribute,不是轉換過的verbose
            n = getattr(obj, i)
            #如果这是datetime.datetime的实例，只取日期显示
            if isinstance(n, datetime.datetime):
                n = n.date
            temp.append(n)
        dic['id'] = id
        dic['data'] = temp
        dic['seq'] = count

        total.append(dic)
    # total look like [{'id':1,data:[...]},{'id':2,data:[...]}]
    return total

def getmodelfield(appname,modelname,exclude):
    """
    获取model的verbose_name和name的字段

    appname : 本app里面 app 的名字
    modelname: 是本app里的models中一个class的名子
    exclude: 是不显示字段
    """
    
    filed = getAllFieldsOFModelClass(appname,modelname)
    #getAllFieldsOFModelClass(appname,modelname)会得到名为appname下的 models.py里 名为 modelname的每一个字段

    fielddic = {}
 
    params = [f for f in filed if f.name not in exclude]
 
    for i in params:
        fielddic[i.name] = i.verbose_name
    # fielddic 
    # looks like {'id': 'id', '月份': '月份', '用水量': '用水量(m3)', '金额1': '金额(元)', '用电量': '用水量(kw.h)', '金额2': '金额(元)', 'bind': 'bind'}
    # dic's key is model attribute, value is verbose
    return fielddic

def getAllFieldsOFModelClass(appname,modelname):
    '''
    获取model的verbose_name和name的字段

    appname : 本app里面 app 的名字
    modelname: 是本app里的models中一个class的名子

    '''

    from django.apps import apps
    '''
    apps 得到这个 <django.apps.registry.Apps object at 0x0000000004A0B688>
    '''
    modelobj = apps.get_model(appname, modelname)
    '''
    apps.get_model(appname, modelname)得到这个  <class '用电量.models.table1'>
    '''
    fileds = modelobj._meta.fields
    '''
    modelobj._meta.fields 得到表的 每一个字段

    (<django.db.models.fields.AutoField: id>, <django.db.models.fields.CharField: 年份>, 
    <django.db.models.fields.IntegerField: 月份>, <django.db.models.fields.CharField: 电使用量千瓦时>,
    <django.db.models.fields.FloatField: 金额元>, <django.db.models.fields.CharField: 使用部门>)
    '''
    return fileds




def getHeader(obj:dict,**vardict) -> list:
    '''
    param: dict
    result: 得到字典的所有key的list从字典從第幾位到開始到第幾位結束
    '''
    # 如果沒有沒有CS指明，代表取表的所有value
    if vardict['cs'] is None:
        lst = []
        #得到obj的所有key
        for i in obj:
            lst.append(i)
        #返回规定位数的key的
        # print('end is',vardict['end'])
        return lst[vardict['start']:vardict['end']]
    else:
        # 如果沒有有CS指明，想要得到header，通常是verbose
        cs = vardict['cs']
        lst = []
        #得到obj的所有key
        for i in obj:
            # print('i is',i)
            if i not in cs:
                # print('none is ',i)
                pass
            else:
                # print('in here i ',i)
                lst.append(cs[i])
        #返回规定位数的key的
        # print('end is',vardict['end'])
        return lst[vardict['start']:vardict['end']]

def getColoumnsCompare(lst,attr1,attr2):
    lst1 = []
    lst2 = []
    for obj in lst:
        lst1.append(getattr(obj,attr1))
        lst2.append(getattr(obj,attr2))
    
    lst3 = []
    for item1,item2 in zip(lst1,lst2):
        item = item2 - item1
        lst3.append(item)
    return lst3

def getAppName():
    from pathlib import Path
    BASE_DIR = Path(__file__).resolve().parent
    appName = str(BASE_DIR).split('\\')[-1]
    return appName

def getThirdAppLib(request,appName):
    import importlib
    # table1 = importlib.import_module('.models', package=appName)
    module=importlib.import_module(appName+".models")
    return module.table1

def getThirdAppLib1(appName):
    import importlib
    # table1 = importlib.import_module('.models', package=appName)
    module=importlib.import_module(appName+".models")
    return module.table1

def mySerialize(serializerObj):
    mySerializer = []
    for i in serializerObj:
        collector = {}
        collector['pk'] = i['pk'] 
        for j in i['fields']:
            collector[j] = i['fields'][j]
        mySerializer.append(collector)
    return mySerializer
def getUrlParameter(request,token):
    url = request.get_full_path()
    url = urllib.parse.unquote(url)
    params = url.split(token)[-1]
    return params

def getFullUrl(request):
    url = request.get_full_path()
    url = urllib.parse.unquote(url)
    return url


def getHandWriteAttri(modelName,tempModelName):
    '''
    description:
        得到一个class 所有非默认的参数
    implements method:
        通过globals()['className']得到一个class的的所有Attri,包括默认加手写
        减去一个class的默认的Attri
    requirements: form .models import *
    params: 
        tempModelName:'tempModel'
        modelName: 'table1'
    '''
    modelTempAttriList = list(globals()[tempModelName].__dict__.keys())
    modelAttrilist = list(globals()[modelName].__dict__.keys())
    handWriteAttriList = [i for i in modelAttrilist if i not in modelTempAttriList]
    return handWriteAttriList


    
    

exclude = ['username','email','is_staff','last_login','password','last_name','date_joined','is_active','is_superuser']