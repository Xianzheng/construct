from django.shortcuts import render, redirect
from django.http.response import HttpResponse, FileResponse
from django.contrib.auth.decorators import login_required
from .models import *
from .tools import *
from .tools_visual import *
from .tools2 import *
from pathlib import Path
import os,json
import pandas as pd
from pandas import DataFrame
from django.db.models import Sum
BASE_DIR = Path(__file__).resolve().parent
appName = str(BASE_DIR).split('\\')[-1]

def monthDataAnalyze_view(request,data):
     #得到filename下模块名称表
    root = os.getcwd()
    print(data)
    # print(type(data))
    data = data.replace('\'','').replace('[','').replace(']','')
    data = data.split(',')
    # print(data)
    currentYear = int(data[0])
    currentMonth = int(data[1])
    # return HttpResponse('hello')
    modelsList = getModelList('./{}/models.py'.format(appName))
    department = getUrlParameter(request,'department=')

    xRes1 = []
    yRes1 = []
    yRes = []
    yRes2 = []
   
    #创建一个字典收集结果，如果把字典放在for循环里每次都是空的字典
    db = getThirdAppLib(request,appName).objects.filter(年份 = str(currentYear - 1) , 月份 = str(currentMonth),使用部门 = department)
    if db:
        for i in db:
            r = dict(list(i.__dict__.items())[4:-2])
            # print(r)
            print('aaa',r)
        yRes = list(r.values())
    else:
        yRes = []

    # yRes是上一年的数据

    
    db1 = getThirdAppLib(request,appName).objects.filter(年份 = str(currentYear), 月份 = str(currentMonth),使用部门 = department)
    if db1:
        for i in db1:
            r1 = dict(list(i.__dict__.items())[4:-2])
            print('bbb',r1)
        
        xRes1 = list(r1.keys())
        yRes1 = list(r1.values())

    else:
        yRes1 = []

    #yRes1是今年数据

    db2 = getThirdAppLib(request,appName).objects.filter(年份 = str(currentYear), 月份 = str(currentMonth - 1),使用部门 = department)
    if db2:
        for i in db2:
            r2 = dict(list(i.__dict__.items())[4:-2])
        
        yRes2 = list(r2.values())
    else:
        yRes2 = []

    #yRes2是上个月数据
    # print('XXX',xRes1)
    # print('YYY',yRes1)
    
    # return render(request,renderFile,{'xRes':json.dumps(xRes),'yRes':json.dumps(yRes),'pieResult':json.dumps(pieResult),'appName':'app'})
    return render(request,'./visual/renderVisual.html',{'xRes':json.dumps(xRes1),'yRes':json.dumps(yRes),
                                                        'yRes1':json.dumps(yRes1),'yRes2':json.dumps(yRes2),
                                                        'currentYear':json.dumps(currentYear),'currentMonth':json.dumps(currentMonth),
                                                        'appName':'app'})

def constantDataAnalyze_view(request):

    #显示路径，通过路径得到app name 和 deparment name
    url = request.get_full_path()
    #decode网页中文乱码

    
    url = urllib.parse.unquote(url)
    year = ''
    if 'year=' in url:
        lst = url.split('year=')
        year = lst[1][0:4]
        print(year)
    else:
        # print('BBBBB')
        pass
    print(url)
    #通过'/'分离路径信息,lst[1]是projectName
    appName = url.split('/')[1]
    #通过'department='分离，lst[-1]是department name
    departmentName = url.split('department=')[-1]

    yResAttri = getHandWriteAttri('table1','tempModel')[-3]
    # print(yResAttri)

    xRes = []
    yRes = []
    lib = getThirdAppLib(request,appName)
    #显示排序
    if year == '':
        year = '2021'
    
    if year == '':
        obj = lib.objects.filter(使用部门=departmentName).order_by('年份','月份')
    else:
        obj = lib.objects.filter(使用部门=departmentName,年份=year).order_by('年份','月份')

    # obj =  list(obj)
   
    # def sortByX(x):
    #     if len(x.月份) < 2:
    #         return int(x.年份+ '0' + x.月份) 
    #     else:
    #         return int(x.年份+x.月份)

    # obj.sort(key=sortByX)

    #算出总和
    if year == '':
        year = 2021
    
    sum1 = lib.objects.filter(使用部门=departmentName,年份='2021').aggregate(num = Sum('水使用量吨'))
    sum2 = lib.objects.filter(使用部门=departmentName,年份='2021').aggregate(num = Sum('金额元'))
    sum1Title = str(year)+appName+'总和'
    sum2Title = str(year)+appName+'总金额'

    for item in obj:
        xRes.append('{}年{}月'.format(item.年份,item.月份))
        yRes.append(getattr(item,yResAttri))
    # xRes = xRes[0:6]
    # yRes = yRes[0:6]

    # print('xxx',xRes)
    # print('yyy',yRes)
    # print(sum1['num'])
    return render(request,'./visual/renderVisual1.html',
        {'xRes':json.dumps(xRes),'yRes':json.dumps(yRes),
        'sum1':json.dumps(sum1['num']),'sum2':json.dumps(sum2['num']),
        'sum1Title':json.dumps(sum1Title),'sum2Title':json.dumps(sum2Title)})

def getYearOption_view(request):
    #显示路径，通过路径得到app name 和 deparment name
    url = request.get_full_path()
    #decode网页中文乱码
    url = urllib.parse.unquote(url)
    # print(url)
    #通过'/'分离路径信息,lst[1]是projectName
    appName = url.split('/')[1]
    #通过'department='分离，lst[-1]是department name
    departmentName = url.split('department=')[-1]
    # print(departmentName)

    lib = getThirdAppLib(request,appName)

    objquery = lib.objects.filter(使用部门=departmentName).all()
    # print(objquery)
    s = set()

    for i in objquery:
        s.add(i.年份)

    
    yearLst = sorted(list(s))
    
    # print(yearLst)
    return HttpResponse(json.dumps(yearLst))
